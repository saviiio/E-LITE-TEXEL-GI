#version 120

#define MATERIAL_TAG 0.07
#define ALPHA_TEST_REF 0.02
#define TRANSLUCENT_PASS
#define GBUFFER_VERTEX
#include "/lib/gbuffer_shared.glsl"
