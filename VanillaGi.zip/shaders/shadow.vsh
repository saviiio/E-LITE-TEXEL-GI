#version 120

#define SHADOW_VERTEX
#include "/lib/shadow_shared.glsl"
