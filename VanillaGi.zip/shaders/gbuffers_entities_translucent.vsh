#version 120

#define MATERIAL_TAG 0.24
#define ALPHA_TEST_REF 0.02
#define TRANSLUCENT_PASS
#define USE_ENTITY_COLOR
#define GBUFFER_VERTEX
#include "/lib/gbuffer_shared.glsl"
