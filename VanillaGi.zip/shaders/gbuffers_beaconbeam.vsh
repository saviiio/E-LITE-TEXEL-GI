#version 120

#define MATERIAL_TAG 0.13
#define ALPHA_TEST_REF 0.02
#define TRANSLUCENT_PASS
#define BEACON_BEAM_PASS
#define GBUFFER_VERTEX
#include "/lib/gbuffer_shared.glsl"
