#version 120

#define MATERIAL_TAG 0.17
#define GBUFFER_VERTEX
#include "/lib/gbuffer_shared.glsl"
