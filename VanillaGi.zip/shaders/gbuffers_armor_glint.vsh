#version 120

#define MATERIAL_TAG 0.15
#define ALPHA_TEST_REF 0.02
#define TRANSLUCENT_PASS
#define GLINT_PASS
#define GBUFFER_VERTEX
#include "/lib/gbuffer_shared.glsl"
