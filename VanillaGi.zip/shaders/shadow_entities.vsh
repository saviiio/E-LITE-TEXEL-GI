#version 120

#define USE_ENTITY_COLOR
#define SHADOW_VERTEX
#include "/lib/shadow_shared.glsl"
