#version 120

#define MATERIAL_TAG 0.19
#define ALPHA_TEST_REF 0.04
#define TRANSLUCENT_PASS
#define WATER_PASS
#define GBUFFER_VERTEX
#include "/lib/gbuffer_shared.glsl"
