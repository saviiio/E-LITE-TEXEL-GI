#ifndef GBUFFER_SHARED_GLSL
#define GBUFFER_SHARED_GLSL

#include "/lib/common.glsl"

#ifndef MATERIAL_TAG
#define MATERIAL_TAG 0.00
#endif

#ifndef ALPHA_TEST_REF
#define ALPHA_TEST_REF 0.001
#endif

#ifdef GBUFFER_VERTEX
varying vec2 vTexCoord;
varying vec2 vLightmap;
varying vec4 vVertexColor;
varying vec3 vWorldPos;
varying vec3 vWorldNormal;
#endif

#ifdef GBUFFER_FRAGMENT
varying vec2 vTexCoord;
varying vec2 vLightmap;
varying vec4 vVertexColor;
varying vec3 vWorldPos;
varying vec3 vWorldNormal;
#define outColor0 gl_FragData[0]
#define outColor1 gl_FragData[1]
#define outColor2 gl_FragData[2]
uniform sampler2D gtexture;
#endif

#ifdef USE_ENTITY_COLOR
uniform vec4 entityColor;
#endif

vec2 getBaseTexCoord() {
    return (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
}

vec2 getBaseLightmapCoord() {
    return (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
}

vec3 getVertexWorldPosition() {
    return (gbufferModelViewInverse * (gl_ModelViewMatrix * gl_Vertex)).xyz;
}

vec3 getVertexWorldNormal() {
    return safeNormalize(mat3FromMat4(gbufferModelViewInverse) * (gl_NormalMatrix * gl_Normal));
}

vec4 getVertexColorModulation() {
    return stripVanillaShadingKeepTint(gl_Color);
}

#ifdef GBUFFER_FRAGMENT
vec4 applyEntityOverlayToSample(vec4 sampledColor) {
#ifdef USE_ENTITY_COLOR
    sampledColor.rgb = mix(sampledColor.rgb, entityColor.rgb, saturate(entityColor.a));
#endif
    return sampledColor;
}

vec4 sampleBaseAlbedo(vec2 texCoord, vec4 vertexColor) {
    vec4 texel = texture2D(gtexture, texCoord);
    vec4 sampledColor = vec4(applyFaceAwareVertexTint(texel.rgb, vertexColor.rgb), texel.a * vertexColor.a);
    return applyEntityOverlayToSample(sampledColor);
}

float getAlphaTestThreshold() {
    return ALPHA_TEST_REF;
}

void applyAlphaTest(float alpha) {
    if (alpha < getAlphaTestThreshold()) {
        discard;
    }
}

vec4 packLightmapMaterial(vec2 lightmap, float materialTag, float texelIndex) {
    float maxTexelIndex = max(GI_TEXEL_GRID_SIZE * GI_TEXEL_GRID_SIZE * 6.0 - 1.0, 1.0);
    return vec4(saturate(lightmap), materialTag, saturate(texelIndex / maxTexelIndex));
}

vec3 applyMaterialTint(vec3 albedo) {
#ifdef WATER_PASS
    albedo *= vec3(0.72, 0.90, 0.98);
#endif
#ifdef GLINT_PASS
    albedo *= vec3(0.80, 0.65, 1.20);
#endif
#ifdef SPIDER_EYES_PASS
    albedo *= vec3(1.05, 0.18, 0.18);
#endif
#ifdef BEACON_BEAM_PASS
    albedo *= vec3(0.85, 1.00, 1.25);
#endif
#ifdef LIGHTNING_PASS
    albedo *= vec3(1.40, 1.48, 1.60);
#endif
    return albedo;
}
#endif

#ifdef GBUFFER_VERTEX
void main() {
    vTexCoord = getBaseTexCoord();
    vLightmap = getBaseLightmapCoord();
    vVertexColor = getVertexColorModulation();
    vWorldPos = getVertexWorldPosition();
    vWorldNormal = getVertexWorldNormal();
    gl_Position = ftransform();
}
#endif

#ifdef GBUFFER_FRAGMENT
/* DRAWBUFFERS:012 */
void main() {
    vec4 base = sampleBaseAlbedo(vTexCoord, vVertexColor);

#ifdef SKY_PASS
    base.rgb *= vec3(1.0);
#endif

    applyAlphaTest(base.a);

    vec3 normal = safeNormalize(vWorldNormal);
    float texelIndex = getFaceTexelIndex(vWorldPos, normal);

    vec3 albedo = applyMaterialTint(base.rgb);
#ifdef WATER_PASS
    albedo = mix(albedo, vec3(0.04, 0.10, 0.12), 0.15);
#endif
#ifdef CUTOUT_PASS
    albedo *= 1.0;
#endif

    float outAlpha = 1.0;
#ifdef TRANSLUCENT_PASS
    outAlpha = clamp(base.a, 0.02, 1.0);
#endif
#ifdef WATER_PASS
    outAlpha = max(outAlpha, 0.18);
#endif

    outColor0 = vec4(sanitizeColor(albedo), outAlpha);
    outColor1 = packLightmapMaterial(vLightmap, MATERIAL_TAG, texelIndex);
    outColor2 = vec4(encodeNormalToColor(normal), 1.0);
}
#endif

#endif
