#version 120

#define MATERIAL_TAG 0.05
#define ALPHA_TEST_REF 0.001
#define SKY_PASS
#define TRANSLUCENT_PASS
#define GBUFFER_VERTEX
#include "/lib/gbuffer_shared.glsl"
