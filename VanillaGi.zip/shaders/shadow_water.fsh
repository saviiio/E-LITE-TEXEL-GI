#version 120

#define SHADOW_ALPHA_TEST_REF 0.04
#define WATER_SHADOW
#define SHADOW_FRAGMENT
#include "/lib/shadow_shared.glsl"

