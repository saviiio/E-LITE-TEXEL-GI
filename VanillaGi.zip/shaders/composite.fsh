#version 120

#include "/lib/composite_shared.glsl"

varying vec2 vTexCoord;


/* DRAWBUFFERS:03 */

void main() {
    float depth = sampleSceneDepth(vTexCoord);

    if (depth >= 1.0) {
        vec3 skyColor = getSimpleGradientSky(vTexCoord);
        gl_FragData[0] = vec4(skyColor, 1.0);
        // colortex3 guarda somente o histórico temporal da iluminação indireta.
        // Céu/fundo não deve contaminar a acumulação da GI.
        gl_FragData[1] = vec4(0.0);
        return;
    }

    vec4 albedo = sampleSceneAlbedo(vTexCoord);
    vec4 lightmapMaterial = sampleSceneLightmapMaterial(vTexCoord);
    vec3 normal = sampleSceneNormal(vTexCoord);
    vec3 worldPos = screenToWorld(vTexCoord, depth);

    vec3 temporalIndirect = vec3(0.0);
    vec3 color = composeLitSurfaceWithTemporalIndirect(vTexCoord, worldPos, normal, albedo.rgb, lightmapMaterial.xy, temporalIndirect);

    // colortex0 recebe a cor final; colortex3 recebe somente a GI acumulada.
    gl_FragData[0] = vec4(color, 1.0);
    gl_FragData[1] = vec4(temporalIndirect, 1.0);
}
