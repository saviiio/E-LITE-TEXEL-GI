#version 120

#define MATERIAL_TAG 0.21
#define ALPHA_TEST_REF 0.02
#define TRANSLUCENT_PASS
#define GBUFFER_FRAGMENT
#include "/lib/gbuffer_shared.glsl"
