#version 120

#define MATERIAL_TAG 0.25
#define GBUFFER_FRAGMENT
#include "/lib/gbuffer_shared.glsl"
