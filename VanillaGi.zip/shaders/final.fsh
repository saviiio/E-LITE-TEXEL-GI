#version 120

#include "/lib/common.glsl"

varying vec2 vTexCoord;
uniform sampler2D colortex0;


void main() {
    vec4 color = texture2D(colortex0, vTexCoord);
    color.rgb = sanitizeColor(color.rgb);
    color.rgb = pow(clamp(color.rgb, vec3(0.0), vec3(65000.0)), vec3(1.0 / FINAL_GAMMA));
    gl_FragData[0] = vec4(color.rgb, clamp(color.a, 0.0, 1.0));
}
