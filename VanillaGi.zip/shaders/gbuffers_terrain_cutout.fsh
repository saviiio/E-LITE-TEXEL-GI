#version 120

#define MATERIAL_TAG 0.26
#define ALPHA_TEST_REF 0.10
#define CUTOUT_PASS
#define GBUFFER_FRAGMENT
#include "/lib/gbuffer_shared.glsl"
