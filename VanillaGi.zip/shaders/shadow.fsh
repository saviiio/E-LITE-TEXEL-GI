#version 120

#define SHADOW_FRAGMENT
#include "/lib/shadow_shared.glsl"

