#version 120

#define MATERIAL_TAG 0.14
#define USE_ENTITY_COLOR
#define GBUFFER_VERTEX
#include "/lib/gbuffer_shared.glsl"
