#version 120

#define MATERIAL_TAG 0.20
#define ALPHA_TEST_REF 0.04
#define TRANSLUCENT_PASS
#define WATER_PASS
#define GBUFFER_FRAGMENT
#include "/lib/gbuffer_shared.glsl"
