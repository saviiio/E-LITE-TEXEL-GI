#version 120

#define MATERIAL_TAG 0.06
#define ALPHA_TEST_REF 0.001
#define SKY_PASS
#define TRANSLUCENT_PASS
#define GBUFFER_FRAGMENT
#include "/lib/gbuffer_shared.glsl"
