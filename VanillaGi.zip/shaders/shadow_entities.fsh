#version 120

#define USE_ENTITY_COLOR
#define SHADOW_ALPHA_TEST_REF 0.02
#define SHADOW_FRAGMENT
#include "/lib/shadow_shared.glsl"

